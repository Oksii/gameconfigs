-|Scheme's RTCW Spawn Timer Config|-


INSTALLATION
------
-Unzip the timer folder to your RTCW/Main directory
-In-game exec timer/timer.cfg

USAGE
------
-Find the map/team you are playing on using the kp_slash and * (Also keypad) keys. 
-The config is already configured so if you choose Beach/Axis, it will time for Allies, so pick YOUR team, not your opponent's.
-Slash is previous and * is next.
-When you have chosen a map/team combination, hit kp_minus to load the config for that combination
-When you see your opponent's spawn, look in the left hand corner to see what the exact time is, and push the corresponding numbers on your keypad
 EXAMPLE: If you see your opponent's spawn and your time reads "5:24", hit 2 and then 4 on the keypad.
-The timer will automatically configure the next two spawns of your opponent's
 NOTE: On 40 second spawns such as Axis on Beach, the 40 second spawn misconstrews timing on spawns,
       so that spawns are not the same every minute. In cases like this, you must continually change the spawn times,
       however, after one change in spawn it will resort to the same movement.
 For instance, if Axis spawns at 24, their next spawns are 44/04/24/44
-If you forget spawn times or a teammate needs them again, simply hit kp_enter and it will re-display
-If you accidentally type the wrong number, just type it in again, the config automatically fixes it

NOTES
------
-scheme@sbcglobal.net if you have any questions/comments

"Bringing competitive RTCW back to the community, one fallen elitist at a time"